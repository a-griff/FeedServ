/* FeedServ v1.0 - rssreader.js (browser-side only) */

const TIMEOUT_MS = 10000;
const PROXIES = [
  "https://api.allorigins.win/get?url=",
  "https://api.codetabs.com/v1/proxy?quest="
];

async function fetchWithTimeout(resource, timeout = TIMEOUT_MS) {
  return Promise.race([
    fetch(resource),
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error("timeout")), timeout)
    )
  ]);
}

async function loadFeed(container, url, maxItems) {
  container.innerHTML = `<p>Loading feed...</p>`;
  try {
    const feedUrl = PROXIES[0] + encodeURIComponent(url);
    const res = await fetchWithTimeout(feedUrl);
    if (!res.ok) throw new Error("HTTP " + res.status);
    const data = await res.json();
    const parser = new DOMParser();
    const xml = parser.parseFromString(data.contents, "text/xml");
    const items = xml.querySelectorAll("item, entry");
    if (!items.length) throw new Error("No items found");
    const title = xml.querySelector("channel > title, feed > title");
    let html = `<h3>${title ? title.textContent : url}</h3><ul>`;
    for (let i = 0; i < Math.min(items.length, maxItems); i++) {
      const t = items[i].querySelector("title")?.textContent || "Untitled";
      const l = items[i].querySelector("link")?.textContent || "#";
      html += `<li><a href="${l}" target="_blank">${t}</a></li>`;
    }
    html += "</ul>";
    container.innerHTML = html;
  } catch (e) {
    container.innerHTML = `<p>Feed error: ${e.message}</p>`;
  }
}

function initFeeds() {
  document.querySelectorAll(".rssbox").forEach(box => {
    const url = box.dataset.feed;
    const max = parseInt(box.dataset.max || "10", 10);
    loadFeed(box, url, max);
  });
}

document.addEventListener("DOMContentLoaded", initFeeds);
